#!/system/bin/sh
# 模块操作脚本 - 使用 input keyevent 确保兼容性

MODDIR=${0%/*}

# 获取当前实际温度墙函数
get_current_wall() {
    # 优先尝试读取/proc/shell-temp
    if [ -f "/proc/shell-temp" ]; then
        shell_temp=$(head -n1 /proc/shell-temp | awk '{print $NF}')
        if [ -n "$shell_temp" ] && [ "$shell_temp" -eq "$shell_temp" ] 2>/dev/null; then
            echo $((shell_temp / 1000 + 15))
            return
        fi
    fi
    
    # 如果失败，尝试读取thermal_zone
    for type in "shell_front" "shell_frame" "shell_back"; do
        zone=$(grep -l "$type" /sys/class/thermal/thermal_zone*/type 2>/dev/null | head -n1)
        if [ -n "$zone" ]; then
            temp=$(cat "${zone%/type}/temp" 2>/dev/null)
            if [ -n "$temp" ]; then
                echo $((temp / 1000 + 15))
                return
            fi
        fi
    done
    
    echo "N/A"
}

# 清屏函数
clear_screen() {
  printf "\033c" 2>/dev/null || printf "\033[2J\033[1;1H" 2>/dev/null || {
    i=0
    while [ $i -lt 30 ]; do
      echo
      i=$((i + 1))
    done
  }
}

# 显示菜单
show_menu() {
  current_wall=$(get_current_wall)
  
  echo "=============================="
  echo "  请选择自定义温控墙温度"
  echo "  (默认51℃，电源键确认)"
  echo "=============================="
  
  i=53
  while [ $i -ge 41 ]; do
    if [ $i -eq $current ]; then
      echo "  [*] $i℃"
    else
      echo "  [ ] $i℃"
    fi
    i=$((i - 1))
  done
  
  echo
  echo "操作说明:"
  echo "  音量+ = 升高温度"
  echo "  音量- = 降低温度"
  echo "  电源键 = 确认选择"
  echo "当前选择: $current℃"
  echo "实际温度墙: $current_wall℃"  # 新增行显示实际温度墙
}

# 设置温度
set_temperature() {
  new_value=$(((current - 15) * 1000))
  
  # 立即生效
  stop horae 2>/dev/null
  for i in 0 1 2 3; do
    echo "$i $new_value" > /proc/shell-temp 2>/dev/null
  done
  
  # 更新配置文件
  if [ -f "$MODDIR/dongtai.sh" ]; then
    sed -i "s/echo \"\$node [0-4][0-9]000\"/echo \"\$node $new_value\"/g" "$MODDIR/dongtai.sh"
    echo "已设置动态温控墙为 ${current}℃ (对应 $new_value)"
  fi
}

# 使用 input keyevent 检测按键
detect_key() {
  # 监听按键事件（兼容所有设备）
  while :; do
    # 获取按键事件
    events=$(getevent -l -c 1)
    
    # 解析按键（只匹配按下事件，忽略释放事件）
    case "$events" in
      *KEY_VOLUMEUP*DOWN*|*VOLUME_UP*DOWN*|*KEY_VOLUME_UP*DOWN*)
        echo "up"
        # 添加延迟防止连击
        sleep 0.3
        return
        ;;
      *KEY_VOLUMEDOWN*DOWN*|*VOLUME_DOWN*DOWN*|*KEY_VOLUME_DOWN*DOWN*)
        echo "down"
        sleep 0.3
        return
        ;;
      *KEY_POWER*DOWN*|*POWER*DOWN*|*KEY_ENTER*DOWN*)
        echo "enter"
        sleep 0.3
        return
        ;;
    esac
  done
}

# 主程序
main() {
  current=51
  
  while true; do
    clear_screen
    show_menu
    
    # 获取按键方向
    key=$(detect_key)
    
    case "$key" in
      "up")
        [ $current -lt 53 ] && current=$((current + 1))
        ;;
      "down")
        [ $current -gt 41 ] && current=$((current - 1))
        ;;
      "enter")
        set_temperature
        echo "设置完成！3秒后返回..."
        sleep 3
        return
        ;;
    esac
  done
}

# 启动主程序
main