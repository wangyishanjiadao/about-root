#!/system/bin/sh
TeamS=${0%/*}
chmod -R 755 "$TeamS"

# 配置参数
PACKAGE_LIST_FILE="包名.txt"
LOG_FILE=$TeamS/horae_control.log
SLEEP_DURATION=30
TEMP_THRESHOLD=370  # 37摄氏度（单位：0.1摄氏度）

# 初始化日志（添加日志轮转功能）
log() {
    echo "$(date '+%Y-%m-%d %T') $1" >> "$LOG_FILE"
    # 日志文件大小限制（1MB）
    log_size=$(stat -c %s "$LOG_FILE" 2>/dev/null || echo 0)
    [ $log_size -gt 1048576 ] && rm -f "$LOG_FILE.old" && mv "$LOG_FILE" "$LOG_FILE.old"
}

# 增强的错误检查
[ -f "$PACKAGE_LIST_FILE" ] || { log "包名列表文件缺失"; exit 1; }
[ -w "/proc/shell-temp" ] || log "警告：缺少/proc/shell-temp写入权限"

# 包名列表动态加载
init_package_list() {
    grep -v '^[[:space:]]*#' "$PACKAGE_LIST_FILE" | 
    tr -d '\r' | 
    awk '{$1=$1};NF' | 
    sort -u
}

# 增强的系统状态检测
get_foreground_pkg() {
    # 多方法获取前台应用
    pkg=$(dumpsys window | awk -F/ '/mCurrentFocus/ {print $1}' | awk '{print $3}')
    [ -z "$pkg" ] && 
    pkg=$(dumpsys activity activities | awk '/mResumedActivity/ {split($4, a, "/"); print a[1]}')
    echo "$pkg" | grep -Eo '[[:alnum:]_]+(\.[[:alnum:]_]+)+' || echo "unknown"
}

is_charging() {
    # 兼容数字和文本状态
    status=$(dumpsys battery | awk '/status:/ {print $2}')
    case "$status" in
        2|5|Charging|Full) return 0 ;;
        *) return 1 ;;
    esac
}

get_temperature() {
    temp=$(cat /sys/class/power_supply/battery/temp 2>/dev/null)
    echo ${temp:-0}  # 处理空值情况
}

# 状态缓存和包名列表版本控制
LAST_STATE="normal"
LAST_PKG_LIST_HASH=""

# 温控设置函数（添加错误处理）
set_thermal_control() {
    for node in 0 1 2 3; do
        if ! echo "$node 36000" > "/proc/shell-temp" 2>/dev/null; then
            log "温控设置失败 node$node"
            return 1
        fi
    done
    return 0
}

# 服务状态管理（添加重试机制）
horae_controller() {
    local state="$1"
    local retries=3

    case "$state" in
        "charging"|"overheat"|"foreground")
            while [ $retries -gt 0 ]; do
                stop horae >/dev/null 2>&1 && break
                retries=$((retries-1))
                sleep 1
            done
            set_thermal_control || log "温控设置失败"
            echo "stop"
            ;;
        *)
            while [ $retries -gt 0 ]; do
                start horae >/dev/null 2>&1 && break
                retries=$((retries-1))
                sleep 1
            done
            echo "start"
            ;;
    esac
}

# 主循环（添加包名列表动态更新）
log "服务启动-优化版"
TMP_PKG_LIST=$(mktemp /data/local/tmp/pkglist.XXXXXX)
init_package_list > "$TMP_PKG_LIST"
trap 'rm -f "$TMP_PKG_LIST"; log "服务停止"; exit 0' EXIT

while true; do
    # 动态更新包名列表（每10次循环检查一次）
    if [ $((cycle_count % 10)) -eq 0 ]; then
        new_hash=$(md5sum "$PACKAGE_LIST_FILE" 2>/dev/null)
        if [ "$new_hash" != "$LAST_PKG_LIST_HASH" ]; then
            init_package_list > "$TMP_PKG_LIST"
            LAST_PKG_LIST_HASH="$new_hash"
            log "包名列表已更新（条目数：$(wc -l < "$TMP_PKG_LIST")）"
        fi
    fi

    current_pkg=$(get_foreground_pkg)
    current_temp=$(get_temperature)
    current_state="normal"

    # 状态优先级判断
    if is_charging; then
        current_state="charging"
        log "当前状态：充电中 温度：${current_temp} 前台应用：$current_pkg"
    elif [ "$current_temp" -ge "$TEMP_THRESHOLD" ]; then
        current_state="overheat"
        log "当前状态：过热 温度：${current_temp} 前台应用：$current_pkg"
    elif grep -q -F -x "$current_pkg" "$TMP_PKG_LIST"; then
        current_state="foreground"
        log "监控应用在前台：$current_pkg"
    fi

    # 状态变更处理
    if [ "$current_state" != "$LAST_STATE" ]; then
        action=$(horae_controller "$current_state")
        log "状态变更: $LAST_STATE -> $current_state 执行: $action"
        LAST_STATE="$current_state"
    fi

    cycle_count=$((cycle_count + 1))
    sleep $SLEEP_DURATION
done