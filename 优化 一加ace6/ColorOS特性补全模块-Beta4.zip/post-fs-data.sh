TMPDIR=${0%/*}/East
for i in `/bin/find $TMPDIR -type f -printf "%P "`; do
    /bin/mount /$TMPDIR/$i /$i
    restorecon /$i
done