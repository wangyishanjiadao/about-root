SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

EastExtensionDir="$MODPATH/East/my_product/etc/extension"

mkdir -p $EastExtensionDir

cp -rf /my_product/etc/extension/com.oplus.app-features.xml $EastExtensionDir
cp -rf /my_product/etc/extension/com.oplus.oplus-feature.xml $EastExtensionDir

awk '
/<\/extend_features>/ {
  print "<!-- 隔膜触控 -->"
  print "\t<app_feature name=\"feature.super_settings_smart_touch.support\"/>"
  print "\t<!-- 跨屏镜像高分辨模式 -->"
  print "\t<app_feature name=\"com.oplus.padconnect.high_resolution\" args=\"boolean:true\"/>"
  print "\t<!-- 苹果手表互联 -->"
  print "\t<app_feature name=\"com.oplus.interconnect.aw.support\" args=\"int:1\"/>"
  print "\t<!-- 游戏助手辅助键(一键连招) -->"
  print "\t<app_feature name=\"feature.support.game.ASSIST_KEY\"/>"
  print "\t<!-- AI游戏辅助4.0 -->"
  print "\t<app_feature name=\"feature.support.game.AI_PLAY_version4_mlbb\"/>"
  print "\t<app_feature name=\"feature.support.game.AI_PLAY_version4\"/>"
  print "\t<app_feature name=\"feature.support.game.AI_PLAY_version4_audio\"/>"
  print "\t<!-- 直播助手 -->"
  print "\t<app_feature name=\"com.oplus.mediaturbo.game_live\" args=\"boolean:true\"/>"
  print "\t<!-- 实况照片支持设置锁屏图片 -->"
  print "\t<app_feature name=\"com.oplus.wallpapers.livephoto_wallpaper\" args=\"boolean:true\"/>"
  print "\t<!-- 微信视频通话功能增强 -->"
  print "\t<app_feature name=\"com.oplus.mediaturbo.wechat_videoCalling\" args=\"boolean:true\"/>"
  print "\t<!-- 侧边栏声音分轨助手 -->"
  print "\t<app_feature name=\"com.oplus.smartmediacontroller.lss_assistant_enable\" args=\"boolean:true\"/>"
  print "\t<!-- AI实况壁纸 -->"
  print "\t<app_feature name=\"com.oplus.wallpapers.ai_camera_movement\" args=\"boolean:true\"/>"
  print "\t<app_feature name=\"com.oplus.wallpapers.livephoto_wallpaper_support_4k\" args=\"boolean:true\"/>"
  print "\t<app_feature name=\"com.oplus.wallpapers.livephoto_wallpaper_support_hdr\" args=\"boolean:true\"/>"
  print "\t<!-- 全场景旁路供电 -->"
  print "\t<app_feature name=\"com.oplus.plc_charge.support\">"
  print "\t\t<StringList args=\"true\"/>"
  print "\t</app_feature>"
  print "\t<app_feature name=\"com.oplus.fullscene_plc_charge.support\" args=\"boolean:true\"/>"
  print "\t<app_feature name=\"com.oplus.reversecharge\" args=\"boolean:true\"/>"  
  print "\t<!-- 全天候息屏显示完整版 -->"
  print "\t<app_feature name=\"oplus.software.disable_aod_all_day_mode\" args=\"boolean:false\"/>"
  print "\t<app_feature name=\"com.oplus.systemui.panoramic_aod_all_day_default_open.enable\" args=\"boolean:true\"/>"
  print "\t<app_feature name=\"com.oplus.systemui.panoramic_aod_all_day.enable\" args=\"boolean:true\"/>"
  print "\t<app_feature name=\"oplus_keyguard_panoramic_aod_all_day_support\" args=\"boolean:true\"/>"
}
{ print }
' $EastExtensionDir/com.oplus.app-features.xml > $EastExtensionDir/com.oplus.app-features.xml.tmp && mv $EastExtensionDir/com.oplus.app-features.xml.tmp $EastExtensionDir/com.oplus.app-features.xml

awk '
/<\/oplus-config>/ {
  print "<!-- 5G网络模式选择 -->"
  print "\t<oplus-feature name=\"oplus.software.radio.show_5g_nr_mode\"/>"
  print "\t<!-- 微信小程序支持多窗口/浮窗 -->"
  print "\t<oplus-feature name=\"oplus.software.support.zoom.open_wechat_mini_program\"/>"
  print "\t<!-- 双小窗特性 -->"
  print "\t<oplus-feature name=\"oplus.software.support.zoom.multi_mode\"/>"
  print "\t<!-- 纸质护眼 -->"
  print "\t<oplus-feature name=\"oplus.software.display.eyeprotect_paper_texture_support\"/>"
  print "\t<!-- 会议网络加速 -->"
  print "\t<oplus-feature name=\"oplus.software.radio.meeting_accelerate\"/>"
  print "\t<!-- 演唱会专网加速 -->"
  print "\t<oplus-feature name=\"oplus.software.radio.data_concert_accelerate\"/>"
  print "\t<!-- 护眼提醒 -->"
  print "\t<oplus-feature name=\"oplus.software.display.ai_eyeprotect_v1_support\"/>"
  print "\t<!-- 侧边栏视频助手 -->"
  print "\t<oplus-feature name=\"oplus.software.smart_sidebar_video_assistant\"/>"
  print "\t<!-- 降低白点值 -->"
  print "\t<oplus-feature name=\"oplus.software.display.reduce_white_point\"/>"
  print "\t<!-- 直播场景加速 -->"
  print "\t<oplus-feature name=\"oplus.software.radio.livebroadcast_accelerate\"/>"
  print "\t<!-- 智慧拖拽 -->"
  print "\t<oplus-feature name=\"oplus.software.smart_loop_drag\"/>"
  print "\t<!-- 录音支持声音焦点 -->"
  print "\t<oplus-feature name=\"oplus.software.audio.record.sound_focus_support\"/>"
  print "\t<!-- 游戏助手清脆振动 -->"
  print "\t<oplus-feature name=\"oplus.software.vibrator.sgame2_crisp_vibration\"/>"
  print "\t<!-- 游戏助手夜间护眼 -->"
  print "\t<oplus-feature name=\"oplus.software.display.game_dark_eyeprotect_support\"/>"
  print "\t<!-- 短按电源键关机 -->"
  print "\t<oplus-feature name=\"oplus.software.short_press_powerkey_shutdown\"/>"
  print "\t<!-- 风驰游戏内核入口 -->"
  print "\t<oplus-feature name=\"oplus.software.game.hummingbird\"/>"
}
{ print }
' $EastExtensionDir/com.oplus.oplus-feature.xml > $EastExtensionDir/com.oplus.oplus-feature.xml.tmp && mv $EastExtensionDir/com.oplus.oplus-feature.xml.tmp $EastExtensionDir/com.oplus.oplus-feature.xml

set_perm_recursive $MODPATH 0 0 0777 0777

