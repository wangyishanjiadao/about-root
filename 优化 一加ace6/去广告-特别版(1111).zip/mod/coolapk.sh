#!/system/bin/sh

id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh



find /data/user/*/com.coolapk.market /data/data/com.coolapk.market /data/media/*/Android/data/com.coolapk.market -iname "tt_mediation_open_sdk.db" -type f -o -iname "GDTDOWNLOAD" -type d -o -iname "tad_cache" -type d -o -iname "app_ad" -type d -o -iname "TTCache" -type d -o -iname "app_ad" -type d -o -iname "cachett_ad" -type d -o -iname "splash_image" -type d -o -iname "tt_tmpl_pkg" -type d -o -iname "com_qq_e_download" -type d -o -iname "pangle_com.byted.pangle" -type d -o -iname "ksad_dynamic" -type d -o -iname "ks_union" -type d -o -iname "app_sodler" -type d -o -iname "BeiZi" -type d -o -iname "offlinepackage" -type d -o -iname "pangle_p" -type d -o -iname "pangle_com.byted.live.lite" -type d -o -iname "gdt_database" -type d -o -iname "app_tt_pangle*" -type d -o -iname "*log*" -type d -o -iname "anythink" -type d -o -perm 000 2>/dev/null | while read adfile ;do
	mkdir_file $adfile 2>/dev/null 
done


function deny_appops(){
local IFS=$'\n'
local package="$1"
local action="$2"
local list="
AUDIO_MEDIA_VOLUME
CHANGE_WIFI_STATE
FINE_LOCATION
LEGACY_STORAGE
MOCK_LOCATION
MONITOR_HIGH_POWER_LOCATION
MONITOR_LOCATION
READ_CALENDAR
READ_DEVICE_IDENTIFIERS
READ_PHONE_STATE
READ_EXTERNAL_STORAGE
SYSTEM_ALERT_WINDOW
TAKE_AUDIO_FOCUS
VIBRATE
WAKE_LOCK
WRITE_CALENDAR
WRITE_EXTERNAL_STORAGE
"
for ops in $list 
do
	cmd appops set $package $ops $action
done
}

deny_appops "com.coolapk.market" "ignore" >/dev/null 2>&1
cmd appops set 'com.coolapk.market' 'allow' 'TOAST_WINDOW' >/dev/null 2>&1

sqlite_file=(
/data/user/*/com.coolapk.market/databases/beizi_ad.db
/data/user/*/com.coolapk.market/databases/ksadcache.db
/data/user/*/com.coolapk.market/databases/ksad_file_download.db
/data/user/*/com.coolapk.market/databases/jaddb.db
/data/user/*/com.coolapk.market/databases/ksadrep.db
/data/user/*/com.coolapk.market/databases/pangle_com.byted.pangle_tt_mediation_open_sdk.db
/data/user/*/com.coolapk.market/databases/pangle*.db
/data/user/*/com.coolapk.market/databases/gdt_*.db
/data/user/*/com.coolapk.market/databases/anythink*.db
/data/user/*/com.coolapk.market/databases/GDT*.db
/data/user/*/com.coolapk.market/databases/*open_sdk.db
)

for file in ${sqlite_file[@]}
do
	if test -f "${file}" ;then
		rm -rf "${file}"
			mkdir -p "${file%/*}"
				touch "${file}"
			chmod 0000 "${file}"
		chown "root:root" "${file}"
	fi
done

rm -rf /data/user/*/com.coolapk.market/files/com_baidu_*send_data* /data/user/*/com.coolapk.market/.jiagu
